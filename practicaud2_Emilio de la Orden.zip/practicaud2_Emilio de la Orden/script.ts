
/* let apellido:HTMLInputElement[]=document.getElementById("apellido")as HTMLInputElement;
let edad:HTMLInputElement[]=document.getElementById("edad")as HTMLInputElement;
let telefono:HTMLInputElement[]=document.getElementById("telefono")as HTMLInputElement;
let fecha_nac:HTMLInputElement[]=document.getElementById("fecha_nac")as HTMLInputElement;
let url:HTMLInputElement[]=document.getElementById("url")as HTMLInputElement; */




function al_reves() {
    const nombre = document.getElementById("nombre") as HTMLInputElement;
    if (nombre && nombre.value) {
        
        const alReves = nombre.reverse();
        console.log(`Palabra original: ${nombre.value}`);
        console.log(`Palabra al revés: ${alReves}`);
    } else {
        console.log("No se ha introducido ningún texto");
    }
}


function redirigir(){

}

function hueco(){


}

function almacenar_cookie(){


}
